package application;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

public class AddNodes {

	private double orgSceneX, orgSceneY;
	private double orgTranslateX, orgTranslateY;

	private double currentTextFieldPosX, currentTextFieldPosY;
	private double currentTextAreaPosX, currentTextAreaPosY;
	private double currentCheckboxPosX, currentCheckboxPosY;

	// retunerar en checkbox
	public CheckBox getCheckbox() {
		CheckBox checkbox = new CheckBox("text");
		checkbox.getText();

		// h�r �r en eventhandler f�r checkboxen som bir skapad
		// evnthandlers uppgift i detta fall �r att f� orginal positionen av
		// noden
		checkbox.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
			orgSceneX = e.getSceneX();
			orgSceneY = e.getSceneY();
			orgTranslateX = ((CheckBox) (e.getSource())).getTranslateX();
			orgTranslateY = ((CheckBox) (e.getSource())).getTranslateY();

			((CheckBox) (e.getSource())).toFront();
		});
		// skapar en eventhandler s� att man kan dra i noden f�r att �ndra
		// posistion
		checkbox.addEventHandler(MouseEvent.MOUSE_DRAGGED, e -> {
			double offsetX = e.getSceneX() - orgSceneX;
			double offsetY = e.getSceneY() - orgSceneY;
			double newTranslateX = orgTranslateX + offsetX;
			double newTranslateY = orgTranslateY + offsetY;

			((CheckBox) (e.getSource())).setTranslateX(newTranslateX);
			((CheckBox) (e.getSource())).setTranslateY(newTranslateY);
		});

		checkbox.getLayoutX();
		checkbox.getLayoutY();
		
		return checkbox;
	}

	// returnerar ett textf�lt
	public TextField getTextField() {

		TextField txt = new TextField();
		txt.setMaxWidth(100);
		txt.setMaxHeight(25);
		// h�r �r en eventhandler f�r checkboxen som bir skapad
		// evnthandlers uppgift i detta fall �r att f� orginal positionen av
		// noden
		txt.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {
			orgSceneX = e.getSceneX();
			orgSceneY = e.getSceneY();
			orgTranslateX = ((TextField) (e.getSource())).getTranslateX();
			orgTranslateY = ((TextField) (e.getSource())).getTranslateY();

			((TextField) (e.getSource())).toFront();
		});
		// skapar en eventhandler s� att man kan dra i noden f�r att �ndra
		// posistion
		txt.addEventHandler(MouseEvent.MOUSE_DRAGGED, e -> {
			System.out.println("is dragged");
			double offsetX = e.getSceneX() - orgSceneX;
			double offsetY = e.getSceneY() - orgSceneY;
			double newTranslateX = orgTranslateX + offsetX;
			double newTranslateY = orgTranslateY + offsetY;
			((TextField) (e.getSource())).setTranslateX(newTranslateX);
			((TextField) (e.getSource())).setTranslateY(newTranslateY);
		});
		txt.getLayoutX();
		txt.getLayoutY();

		return txt;
	}

	// att dra i textarean fungerar ej , returnerar en textarea
	public TextArea getTextArea() {

		TextArea textarea = new TextArea();
		textarea.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> {

			System.out.println("is clicked");

			orgSceneX = e.getSceneX();
			orgSceneY = e.getSceneY();
			orgTranslateX = textarea.getTranslateX();
			orgTranslateY = textarea.getTranslateY();
			textarea.toFront();
		});

		textarea.addEventHandler(MouseEvent.MOUSE_DRAGGED, e -> {

			System.out.println("is dragged");

			double offsetX = e.getSceneX() - orgSceneX;
			double offsetY = e.getSceneY() - orgSceneY;
			double newTranslateX = orgTranslateX + offsetX;
			double newTranslateY = orgTranslateY + offsetY;

			textarea.setTranslateX(newTranslateX);
			textarea.setTranslateY(newTranslateY);
		});

		textarea.getLayoutX();
		textarea.getLayoutY();

		return textarea;
	}

	public Tab getNewTab(AnchorPane pane) {
		return new Tab("new Tab", pane);
	}

	public double getCurrentCheckboxPosX() {
		return currentCheckboxPosX;
	}

	public double getCurrentCheckboxPosY() {
		return currentCheckboxPosY;
	}

	public double getCurrentTextFieldPosX() {
		return currentTextFieldPosX;
	}

	public double getCurrentTextFieldPosY() {
		return currentTextFieldPosY;
	}

	public double getCurrentTextAreaPosX() {
		return currentTextAreaPosX;
	}

	public double getCurrentTextAreaPosY() {
		return currentTextAreaPosY;
	}
}
