package application;

import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;

public class AddTextArea {

    double orgSceneX, orgSceneY;
    double orgTranslateX, orgTranslateY;
	    
	public TextArea getTextArea(){
		  TextArea textarea = new TextArea();
	
	        
	
		return textarea;
	}
}
