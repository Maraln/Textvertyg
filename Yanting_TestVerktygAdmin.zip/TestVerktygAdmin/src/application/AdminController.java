package application;

import java.awt.Label;
import java.util.ArrayList;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Group;

import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * Denna klass har till uppgift att koppa samman de andra klasserna som
 * inehåller logik Controller klassen ska inte innefatta mycket logik klassen
 * innehåller just nu 5 metoder.
 * 
 **/
public class AdminController implements ControlledScreen {
	
	// skapar en referens variabel av klassen ScreenController s� att man kan �ndra till statistik guit
	private ScreenController myController;
	
	@FXML
	private TabPane tabpane;
	@FXML
	
	
	// skapar en arraylist som lagrar anchorpanes , s� man kan h�lla reda p� vilken nod tillh�r vilken tab
	private ArrayList<AnchorPane> anchorPaneList = new ArrayList<>();

	private AddNodes addnodes = new AddNodes();
	private WriteToTextFile write = new WriteToTextFile();
	
	
	@Override
	public void setScreenParent(ScreenController screenPage) {
		myController = screenPage;
	}

	@FXML
	public void onClose() {
		Platform.exit();
	}
	
	@FXML
	public void onNewFile() {
		write.showFileChooser();
	}
	
	@FXML
	public void onAbout() {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("About");
		alert.setHeaderText("Welcome to Admin!");
		alert.setContentText("Write down the instruction.");
		alert.getButtonTypes().remove(1);
		alert.showAndWait();
	}

	@FXML
	public void onAddCheckbox(ActionEvent event) {
		// skapar en oinitizerad anchorpane variabel som jag sedan tilldelar ett v�rde
		
		AnchorPane pane;
		
		// om tabpane inte �r tom(att den har en eller mer tabs) skall denna kod g�ras
		if(!tabpane.getTabs().isEmpty()){
		// jag f�ngar upp den valda anchorpanen och tilldelar den till pane s� jag sedan kan l�gga till noder p� den spesefika tabben som �r vald
			pane = anchorPaneList.get(tabpane.getSelectionModel().getSelectedIndex());
			// lägger till noden till pane
			pane.getChildren().add(addnodes.getCheckbox());
			// sätter pane till tabben
		tabpane.getSelectionModel().getSelectedItem().setContent(pane);
		write.setTextInFile("checkbox");
		write.setTextInFile(String.valueOf(addnodes.getCurrentCheckboxPosX()));
		write.setTextInFile(String.valueOf(addnodes.getCurrentCheckboxPosY()));
		write.setTextInFile(addnodes.getCheckbox().getText());
		}
	}
	
	// lägger till en tab
	@FXML
	public void onAddTab(ActionEvent event) {
		// skapar en ny anchorpane f�r varje tab som skapas 
		AnchorPane pane = new AnchorPane();
		pane.prefHeight(1000);
		pane.prefWidth(1000);
		// lägger till tabben i en arraylist av typen AnchorPane
		anchorPaneList.add(pane);
		// lägger till en ny tab i tabpane och ger den enskilda tabben en anchorpane
		tabpane.getTabs().add(addnodes.getNewTab(pane));
		write.setTextInFile("tab");
		write.setTextInFile("newtab");
	}

	@FXML
	public void onDone(ActionEvent event) {
		
	}

	@FXML
	public void onShowStatistics(ActionEvent event) {
		myController.setScreen(Main.statsScreenID);
	}

	@FXML
	public void onAddTextfield() {
		AnchorPane pane;
		
		if(!tabpane.getTabs().isEmpty()){
			pane = anchorPaneList.get(tabpane.getSelectionModel().getSelectedIndex());
			pane.getChildren().add(addnodes.getTextField());
		tabpane.getSelectionModel().getSelectedItem().setContent(pane);
		write.setTextInFile("textfield");
		}		
	}
	
	@FXML
	public void onCloseTab(){
		System.out.println("close tab");
	}
	
	// l�gger till en textarea
	@FXML
	public void onAddTextarea(){
		AnchorPane pane;
		
		TextArea textarea = new TextArea();
		if(!tabpane.getTabs().isEmpty()){
			pane = anchorPaneList.get(tabpane.getSelectionModel().getSelectedIndex());
			pane.getChildren().add(textarea);
		    tabpane.getSelectionModel().getSelectedItem().setContent(pane);
		    write.setTextInFile("textarea2");
		 }		
	}
	
	@FXML
	public void onDelete(ActionEvent event) {
		if (tabpane.getTabs().isEmpty()) return;
		
		Tab selectedTab = tabpane.getSelectionModel().getSelectedItem();
		tabpane.getTabs().remove(selectedTab);
	}
	
	@FXML
	public void onHandleAdmins(ActionEvent event) {
		
	}
	
	@FXML
	public void onHandleUsers(ActionEvent event) {
		myController.setScreen(Main.userScreenID);
	}
	
	@FXML
	public void onHandleGroups(ActionEvent event) {
		myController.setScreen(Main.groupScreenID);
	}
}
