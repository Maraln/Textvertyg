package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.stage.FileChooser;

public class WriteToTextFile {

	
	
	private ArrayList<String> textList = new ArrayList<>();

	// konstruktor
	WriteToTextFile() {

	}

	public void createAndSave() {

	}

	private void SaveFile(File file) {
		System.out.println(textList.toString());

		try {
			FileWriter fileWriter;

			fileWriter = new FileWriter(file);
			for(int i = 0; i < textList.size(); i++){
				String txt = textList.get(i) + "\r\n";
				fileWriter.write(txt);
			}
			
			fileWriter.close();
		} catch (IOException ex) {
			Logger.getLogger(WriteToTextFile.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

	public void showFileChooser() {

		FileChooser fileChooser = new FileChooser();

		// Set extension filter
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("INI files (*.ini)", "*.ini");
		FileChooser.ExtensionFilter extFilter2 = new FileChooser.ExtensionFilter("RTF files (*.rtf)", "*.rtf");
		fileChooser.getExtensionFilters().addAll(extFilter, extFilter2);

		// Show save file dialog
		File file = fileChooser.showSaveDialog(null);

		if (file != null) {
			SaveFile(file);
		}
	}

	public void setTextInFile(String text) {
		textList.add(text);
	}
}
