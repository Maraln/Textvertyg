package application;

//denna klass �r tagen ifr�n github
public interface ControlledScreen {

	public void setScreenParent(ScreenController screenPage);
}
