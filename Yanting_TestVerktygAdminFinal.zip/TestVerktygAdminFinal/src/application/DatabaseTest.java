package application;

/*
import entity.Question;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author yanting
 */
public class DatabaseTest {
	/*
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Testverktyg1PU");
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction questionTransaction = em.getTransaction();
		
		questionTransaction.begin();
		Question q = new Question();
		q.setText("Sample question?");
		em.persist(q);
		questionTransaction.commit();
		em.close();
		entityManagerFactory.close();
	}
	*/
}
