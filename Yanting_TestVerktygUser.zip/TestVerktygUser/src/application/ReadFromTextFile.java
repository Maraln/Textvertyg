package application;

public class ReadFromTextFile {

}
