package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
// Timer-kod bibliotek
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;

/**
 * denna klass har till uppgift att koppa samman de andra klasserna som
 * ineh�ller logik Controller klassen ska inte innefatta mycket logik klassen
 * inneh�ller just nu 5 metoder
 * 
 **/

public class UserController extends Pane {

	String pathIni = "";
	double X;
	double Y;
	String text = "";
	private int timerDuration = 3286;
	private Timeline timerTimeline;

	private int iterator = -1;

	private ArrayList<AnchorPane> anchorPaneList = new ArrayList<>();

	@FXML
	private Button backButton;
	@FXML
	private Button nextButton;
	@FXML
	private Button finnishButton;
	@FXML
	private TabPane tabPane;
	@FXML
	private Label currentTime;
	@FXML
	private Label timer;
	
	@FXML
	public void initialize() {
		Timeline ctTimeline = new Timeline(new KeyFrame(
				Duration.millis(1000),
		        event -> updateCurrentTime()));
		ctTimeline.setCycleCount(Animation.INDEFINITE);
		ctTimeline.play();
		
		timerTimeline = new Timeline(new KeyFrame(
				Duration.millis(1000),
		        event -> updateTimer()));
		timerTimeline.setCycleCount(timerDuration * 1000);
		timerTimeline.play();		
	}
	
	public void updateCurrentTime() {
		currentTime.setText("" + new Date());
	}
	
	public void updateTimer() {
		timerDuration--;

		if (timerDuration < 0) {
			timerTimeline.stop();
		}
		
		LocalTime timeOfDay = LocalTime.ofSecondOfDay(timerDuration);
		
		text = "Time left: " + timeOfDay;
		timer.setText(text);
	}

	// eventsen f�r knapparna
	@FXML
	public void onBack(ActionEvent event) {
		System.out.println("knappen funkar");
	}

	@FXML
	public void onNext(ActionEvent event) {
		System.out.println("knappen funkar");
	}

	@FXML
	public void onFinnish(ActionEvent event) {
		readFromTextFile();
		System.out.println("knappen funkar");
	}

	@FXML
	public void onFileOpen(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Resource File");
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.ini"));
		File selectedFile = fileChooser.showOpenDialog(null);
		if (selectedFile != null) {
			selectedFile.getPath();
			pathIni = selectedFile.toString();
			readFromTextFile();

		}
	}
	
	@FXML
	public void onClose(ActionEvent event) {
		Platform.exit();
	}
	
	@FXML
	public void onAbout(ActionEvent event) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("About...");
		alert.setHeaderText("Welcome to the Java examination!");
		alert.setContentText("Enjoy!");
		alert.getButtonTypes().remove(1);
		alert.showAndWait();
	}

	public void readFromTextFile() {

		AnchorPane group = new AnchorPane();

		group.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> {
			// System.out.println(e.getX());
			// System.out.println(e.getY());
		});

		try (Scanner sc = new Scanner(new File(pathIni))) {
			while (sc.hasNextLine()) {
				String name = sc.nextLine();

				// Sends information to create a combobox on the specified
				// coordinates in the textfile
				if (name.equals("checkbox")) {
					if (sc.hasNextDouble())
						;
					{
						X = sc.nextDouble();
						Y = sc.nextDouble();
						text = sc.next();
					}
					// group.getChildren().add(createCheckbox(X, Y));
					// tabPane.getSelectionModel().getSelectedItem().setContent(group);

					AnchorPane pane;

					pane = anchorPaneList.get(iterator);
					pane.getChildren().add(createCheckbox(X, Y));

				}
				// Sends information to create a textfield on the specified
				// coordinates in the textfile
				if (name.equals("textfield")) {
					if (sc.hasNextDouble())
						;
					{
						if (sc.hasNextLine())
							;
						X = sc.nextDouble();
						Y = sc.nextDouble();
						text = sc.next();
					}
					AnchorPane pane;
					pane = anchorPaneList.get(iterator);
					pane.getChildren().add(createTextField(X, Y));

					// group.getChildren().add(createTextField(X, Y));
					// tabPane.getSelectionModel().getSelectedItem().setContent(group);
				}
				// Sends information to create a textarea on the specified
				// coordinates in the textfile
				if (name.equals("textarea")) {
					if (sc.hasNextDouble())
						;
					{
						X = sc.nextDouble();
						Y = sc.nextDouble();
						text = sc.next();
					}
					// group.getChildren().add(createTextArea(X, Y));
					// tabPane.getSelectionModel().getSelectedItem().setContent(group);

					AnchorPane pane;
					pane = anchorPaneList.get(iterator);
					pane.getChildren().add(createTextArea(X, Y));
					tabPane.getTabs().get(iterator).setContent(pane);

				}
				if (name.equals("tab")) {
					iterator++;
					AnchorPane pane = new AnchorPane();
					pane.prefHeight(1000);
					pane.prefWidth(1000);
					anchorPaneList.add(pane);
					System.out.println(iterator);
					text = sc.next();
					text = text.replace("_", " ");
					Tab tab = new Tab(text, pane);
					tabPane.getTabs().add(tab);

					// tabPane.getSelectionModel().select(tab);

					// SingleSelectionModel<Tab> selectionModel =
					// tabPane.getSelectionModel();
					// selectionModel.select(tab); // select by object
					// selectionModel.select(0); // select by index starting
					// with 0

				}
			}
		} catch (FileNotFoundException e) {

		}
	}

	// Creates checkbox
	public CheckBox createCheckbox(double x, double y) {
		// HBox box = new HBox(new CheckBox(), new TextField());
		// box.setAlignment(Pos.BASELINE_CENTER);
		// box.setLayoutX(x);
		// box.setLayoutY(y);
		// return box;
		text = text.replace("_", " ");
		CheckBox cb = new CheckBox(text);
		cb.setLayoutX(x);
		cb.setLayoutY(y);
		return cb;

	}

	// Creates textfield
	public TextField createTextField(double x, double y) {
		text = text.replace("_", " ");
		TextField tf = new TextField(text);
		tf.setEditable(false);
		tf.setPrefSize(705, 20);
		tf.setLayoutX(x);
		tf.setLayoutY(y);
		return tf;

	}

	// Creates textarea
	public TextArea createTextArea(double x, double y) {
		text = text.replace("_", " ");
		TextArea ta = new TextArea(text);
		ta.setPrefSize(705, 135);
		ta.setLayoutX(x);
		ta.setLayoutY(y);
		return ta;

	}

}